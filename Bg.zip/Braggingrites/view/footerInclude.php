		</section>			<!-- End of section id='main' -->
		<footer id="mainFooter" class="clickable">
			<a href='mailto:jodonnell@clarion.edu'>Contact Webmaster</a>
		</footer>
	</div>					<!-- End of wrapper -->
</body>
</html>