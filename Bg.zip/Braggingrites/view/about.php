<?php
	$title = "About";
	require '../view/headerInclude.php';
?>
<h1>This side created for CIS 370.</h1>

<?php
	require '../view/footerInclude.php';
?>
