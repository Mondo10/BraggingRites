<?php
	$title = "Page 2";
	require '../view/headerInclude.php';
?>
<h1>This is Page 2.</h1>

<?php
	require '../view/footerInclude.php';
?>
