<?php
	$title = "Error";
	require '../view/headerInclude.php';
?>
<h1><?php echo $errorMessage; ?></h1>

<?php
	require '../view/footerInclude.php';
?>
