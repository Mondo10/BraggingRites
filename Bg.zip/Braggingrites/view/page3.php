<?php
	$title = "Page 3";
	require '../view/headerInclude.php';
?>
<h1>This is Page 3.</h1>

<?php
	require '../view/footerInclude.php';
?>
