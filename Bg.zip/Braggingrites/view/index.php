<?php
	$title = "Home Page";
	require '../view/headerInclude.php';
?>
<h1>This is content.</h1>

<?php
	require '../view/footerInclude.php';
?>

