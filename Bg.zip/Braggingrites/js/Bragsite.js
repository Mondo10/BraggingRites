function loadNavBar() {
    $(document).ready(function() {
        $('#navbar').load('navbar.html');
    });
};